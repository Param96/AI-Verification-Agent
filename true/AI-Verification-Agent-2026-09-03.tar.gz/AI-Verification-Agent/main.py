import os

os.environ["OMP_NUM_THREADS"] = "1"
import asyncio
import aiohttp
import argparse
from pathlib import Path
from tqdm.asyncio import tqdm
from datetime import datetime
from playwright.async_api import async_playwright

from config import CONCURRENCY_LIMIT, BASE_DIR
from utils.logger import logger
from utils.schema import CourseRecord, FinalReportRecord
from utils.checkpoint import CheckpointManager
from parser.dataset_parser import parse_spreadsheet
from parser.vision_pdf_parser import parse_pdf_vision
from crawler.link_validator import validate_link
from crawler.web_scraper import scrape_url
from verifier.integrity_checker import IntegrityChecker
from reports.generator import generate_reports


async def process_record(
    record: CourseRecord,
    session: aiohttp.ClientSession,
    context,
    semaphore: asyncio.Semaphore,
    checkpoint: CheckpointManager,
    checker: IntegrityChecker,
) -> FinalReportRecord:

    async with semaphore:
        # Check if already processed
        if checkpoint.is_processed(record.row_number):
            logger.debug(f"Row {record.row_number} already processed. Skipping.")
            return None

        # 1. Validate Link
        is_valid, status_code, final_url, response_time = await validate_link(
            record.link, session
        )
        link_status_msg = f"HTTP {status_code}" if status_code else "Failed/Timeout"

        if not is_valid:
            final_record = FinalReportRecord(
                row_number=record.row_number,
                institute_name=record.institute_name,
                course_name=record.course_name,
                course_link=record.link or "N/A",
                link_status=link_status_msg,
                verification_status="BROKEN_LINK",
                confidence_score=1.0,
                original_domain=record.field_domain or "Unknown",
                predicted_domain="Unknown",
                domain_match_status="Fail",
                original_course_type=record.course_type or "Unknown",
                original_mode=record.mode or "Unknown",
                original_country=record.country or "Unknown",
                original_skills=record.description or "Unknown",
                original_fees=record.fees or "Unknown",
                original_logo=record.has_uni_logo or False,
                similarity_scores={},
                broken_link_status=True,
                ai_summary="Could not verify because the webpage could not be loaded.",
                timestamp=datetime.now().isoformat(),
                response_time_ms=response_time,
                redirect_status="N/A",
                screenshot_path=None,
            )
            checkpoint.save_processed(record.row_number, final_record.model_dump())
            checkpoint.save_incorrect(record.row_number, final_record.model_dump())
            return final_record

        # 2. Scrape Webpage
        crawl_result = await scrape_url(final_url, context, record.row_number)
        crawl_result.response_time_ms = response_time

        # 3. Integrity Verification (ML + Rules)
        verification_result = checker.check_integrity(record, crawl_result)

        # 4. Fallback to LLM for maximum accuracy if ML Classifier is uncertain or fails
        if (
            verification_result["status"] != "VALID"
            or verification_result["confidence"] < 0.8
        ):
            from ai_engine.comparator import verify_course_data
            from config import DEFAULT_LLM_MODEL

            logger.info(
                f"Row {record.row_number}: ML status {verification_result['status']} ({verification_result['confidence']:.2f}). Falling back to {DEFAULT_LLM_MODEL}..."
            )
            llm_result = await verify_course_data(record, crawl_result)

            # Map LLM statuses to system statuses
            status_map = {
                "MATCH": "VALID",
                "PARTIAL": "PARTIAL_MATCH",
                "MISMATCH": "INVALID",
            }
            llm_stat = llm_result.status.upper()
            verification_result["status"] = status_map.get(llm_stat, llm_stat)
            verification_result["confidence"] = llm_result.confidence

            # Format differences into AI summary
            if not verification_result.get("suggested_correction"):
                verification_result["suggested_correction"] = {}

            if llm_result.differences:
                verification_result["suggested_correction"]["reason"] = (
                    "• " + "\n• ".join(llm_result.differences)
                )
            else:
                verification_result["suggested_correction"][
                    "reason"
                ] = "LLM Verification: Perfect match."

        # 5. Compile Final Record
        features = verification_result.get("features") or {}
        tax_suggestion = verification_result.get("suggested_correction") or {}

        predicted_domain = tax_suggestion.get("suggestion", "Unknown")
        domain_match = "Match" if features.get("domain_match") == 1 else "Mismatch"

        # Extract specifics from LLM result if available
        llm_verified_institute = "Pending"
        llm_verified_mode = "Pending"
        llm_verified_country = "Pending"
        llm_verified_skills = "Pending"
        llm_verified_fees = "Pending"
        llm_verified_logo = "Pending"
        suggested_corrections = []
        mismatched_fields = []

        if "llm_result" in locals():
            llm_verified_institute = llm_result.verified_institute_name
            llm_verified_mode = llm_result.verified_mode
            llm_verified_country = llm_result.verified_country
            llm_verified_skills = llm_result.verified_skills
            llm_verified_fees = llm_result.verified_fees
            llm_verified_logo = llm_result.verified_logo
            suggested_corrections = llm_result.suggested_corrections
            mismatched_fields = [
                k for k, v in llm_result.verified_fields.items() if not v
            ]

        final_record = FinalReportRecord(
            row_number=record.row_number,
            institute_name=record.institute_name,
            course_name=record.course_name,
            course_link=record.link or "N/A",
            link_status=f"HTTP {crawl_result.status_code}",
            verification_status=verification_result["status"],
            confidence_score=verification_result["confidence"],
            original_domain=record.field_domain or "Unknown",
            predicted_domain=predicted_domain,
            domain_match_status=domain_match,
            original_course_type=record.course_type or "Unknown",
            original_mode=record.mode or "Unknown",
            original_country=record.country or "Unknown",
            original_skills=record.description or "Unknown",
            original_fees=record.fees or "Unknown",
            original_logo=record.has_uni_logo or False,
            similarity_scores={
                "course_name": features.get("course_name_similarity", 0.0),
                "institute": features.get("institute_similarity", 0.0),
            },
            broken_link_status=False,
            ai_summary=tax_suggestion.get("reason", "Verification complete."),
            timestamp=datetime.now().isoformat(),
            response_time_ms=crawl_result.response_time_ms or 0,
            screenshot_path=crawl_result.screenshot_path,
            verified_institute_name=llm_verified_institute,
            verified_mode=llm_verified_mode,
            verified_country=llm_verified_country,
            verified_skills=llm_verified_skills,
            verified_fees=llm_verified_fees,
            verified_logo=llm_verified_logo,
            suggested_corrections=suggested_corrections,
            mismatched_fields=mismatched_fields,
            original_dataset_values=record.model_dump(),
            extracted_web_values={
                "text": (
                    crawl_result.extracted_text[:1000]
                    if crawl_result.extracted_text
                    else ""
                )
            },
        )

        checkpoint.save_processed(record.row_number, final_record.model_dump())

        # Save to anomalies table if not strictly VALID
        if final_record.verification_status != "VALID":
            checkpoint.save_incorrect(record.row_number, final_record.model_dump())

        return final_record


async def main(file_path: Path):
    logger.info(f"Starting ML-Driven Data Auditing System for {file_path}")

    # Initialize IntegrityChecker BEFORE any cv2 parsing to avoid OpenCV/PyTorch/XGBoost OpenMP segfaults on macOS
    print("DEBUG: Instantiating IntegrityChecker early...", flush=True)
    checker = IntegrityChecker()

    if file_path.suffix.lower() == ".pdf":
        records = parse_pdf_vision(file_path)
    else:
        records = parse_spreadsheet(file_path)

    if not records:
        logger.error("No valid records found to process. Exiting.")
        return

    # Setup Checkpoint DB
    db_path = BASE_DIR / "logs" / f"checkpoint_{file_path.stem}.sqlite"
    checkpoint = CheckpointManager(db_path)

    # Filter out already processed records
    unprocessed = [r for r in records if not checkpoint.is_processed(r.row_number)]
    logger.info(f"Total Records: {len(records)} | Unprocessed: {len(unprocessed)}")

    if unprocessed:
        print("DEBUG: Preloading dataset...", flush=True)
        checker.preload_dataset(records)
        print("DEBUG: Starting concurrency setup...", flush=True)

        semaphore = asyncio.Semaphore(CONCURRENCY_LIMIT)

        async with aiohttp.ClientSession() as session:
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context(
                    user_agent="Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
                    ignore_https_errors=True,
                    java_script_enabled=True,
                    extra_http_headers={
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
                        "Accept-Language": "en-US,en;q=0.9",
                        "Sec-Fetch-Dest": "document",
                        "Sec-Fetch-Mode": "navigate",
                        "Sec-Fetch-Site": "none",
                        "Sec-Fetch-User": "?1",
                        "Upgrade-Insecure-Requests": "1",
                    },
                )

                tasks = []
                for record in unprocessed:
                    tasks.append(
                        process_record(
                            record, session, context, semaphore, checkpoint, checker
                        )
                    )

                try:
                    await tqdm.gather(*tasks, desc="Verifying Courses")
                except Exception as e:
                    logger.error(f"Error during parallel execution: {e}", exc_info=True)

                await context.close()
                await browser.close()

    # Load ALL processed records from checkpoint DB to generate final report
    all_data_dicts = checkpoint.get_all_processed()
    final_records = [FinalReportRecord(**data) for data in all_data_dicts]

    # Sort back to original order
    final_records.sort(key=lambda x: x.row_number)

    logger.info(f"Generating final reports for {len(final_records)} records...")
    generate_reports(final_records, base_filename=f"audit_{file_path.stem}")
    logger.info("Agent execution completed successfully!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ML-Driven Data Auditing System")
    parser.add_argument(
        "file_path", type=str, help="Path to the Excel, CSV, or PDF dataset."
    )
    args = parser.parse_args()

    input_path = Path(args.file_path).resolve()
    if not input_path.exists():
        print(f"Error: File '{input_path}' does not exist.")
        exit(1)

    asyncio.run(main(input_path))
