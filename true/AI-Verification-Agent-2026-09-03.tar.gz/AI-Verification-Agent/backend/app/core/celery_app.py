from celery import Celery
from app.core.config import settings

celery_app = Celery(
    "verify_worker",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_routes={
        "app.workers.ingestion.*": {"queue": "ingestion_queue"},
        "app.workers.scraper.*": {"queue": "scraper_queue"},
        "app.workers.ai_engine.*": {"queue": "ai_queue"},
    },
)
